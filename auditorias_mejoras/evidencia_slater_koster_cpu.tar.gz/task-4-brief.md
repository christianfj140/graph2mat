### Task 4: benchmark CPU emparejado y protocolo de precisión/GPU

**Files:** nuevo `bench_slater_koster_cpu.py`, `test_slater_koster_benchmark.py`,
`protocolo_gpu_precision_7_4.md`; JSON solo generado por medición real.

**Interfaces:** CLI `--points 72 --rank 4 --rounds 12 --warmup 3`; salida JSON
stdout. Variantes `baseline`, `low_rank`, `sk_residual`; CPU float32 con C2 y
s/p/d/f. Reutilizar `dataset_for` de `bench_cache_tensores_cpu.py` y
`digest_tensors`, `parameters`, `summary` de `bench_readout_rango_bajo.py`.
No modificar los resultados ni la semántica del benchmark histórico.

1. **RED — contrato de benchmark sin medida larga.**

- [ ] Test por subprocess con `--points 4 --rounds 1 --warmup 1 --rank 1`,
  CUDA vacío. JSON contiene tres variantes, medidas crudas no vacías,
  median/MAD recalculables, hashes, `device=cpu` y scopes explícitos. Valorar
  resultado numérico finito, no un tiempo mínimo obligatorio. Código de check:

```python
assert set(result['measure']['full_model']) == {'baseline', 'low_rank', 'sk_residual'}
for phases in result['measure']['full_model'].values():
    for record in phases.values():
        assert len(record['raw_ms']) == result['rounds']
        assert record['median'] == statistics.median(record['raw_ms'])
assert result['device'] == 'cpu'
assert 'vram_bytes' not in result
```

2. **GREEN — medición de igual trabajo, no igual arquitectura.**

- [ ] Tres modelos con backbone/onsite idénticos por carga estricta de estado,
  fixture congelada, dtype/hilos idénticos y semillas registradas. Comparación
  aislada con wrappers del MISMO par s/p/d/f, Q y entradas; no comparar SK de
  orbitales completos con otra operación de irreps recortadas.
- [ ] Medir forward de entrenamiento, backward y paso completo Adam; separar
  construcción/calentamiento. Warmup inicializa optimizador antes de cronometrar
  pasos. Rotar orden de las tres variantes y alternar reverso para que ninguna
  quede siempre en medio. Patrón de orden:

```python
names = ['baseline', 'low_rank', 'sk_residual']
order = names[index % 3:] + names[:index % 3]
if (index // 3) % 2:
    order.reverse()
```

- [ ] Guardar raw_ms por fase/variante y resúmenes median/MAD/min/max. Fuera
  de timing comprobar loss/gradientes finitos, formas, ramas SK y residual
  efectivas y hash del batch inalterado. Registrar política de actualizaciones
  del optimizador, copias/loss incluidas y carga host no aislada.
- [ ] Memoria host en subprocess fresco por variante, misma fixture/secuencia:
  `resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024` en Linux, etiquetado
  `process_peak_rss_bytes`. Incluye imports/construcción/ejecución; no atribuirlo
  solo al readout ni medir variantes acumuladas en el mismo proceso. Guardar
  también bytes de parámetros/buffers con alcance diferenciado; ninguna cifra
  se denomina VRAM. Manejar plataforma no Linux con error explícito del modo
  de memoria, no unidad incorrecta.
  Implementar helper privado `_memory_worker(variant, points, rank, connection)`
  con `multiprocessing.get_context('spawn')` y `Pipe`: el hijo construye UNA
  variante, ejecuta la secuencia fija y envía el récord RSS/scopes. El padre
  comprueba exit code/errores y usa el mismo handle si tarda, sin reiniciarlo
  por timeout de observación. No memoria medida en proceso padre con tres modelos.
- [ ] Ejecutar autocomprobación y luego benchmark principal. Guardar stdout
  real como `resultados_slater_koster_cpu.json` mediante el runner de evidencia;
  no inventar cifras ni escribirlo manualmente. Incluir SHA Git y hashes de
  archivos producto/script, versiones, fixture, dtype e hilos. Probar JSON
  también con Python 3.9 mediante smoke pequeño, no repetir benchmark largo.

3. **Protocolo posterior, no ejecución.**

- [ ] Documentar baseline/7.1/SK+residual, seeds 0/1/2 emparejadas, splits
  congelados y budget por pasos/muestras junto a tiempo para no esconder coste.
  Congelar material/split/scheduler/selección de checkpoint antes de lanzar.
  Dar un preflight que liste los artefactos científicos necesarios; la ausencia
  de dataset/split concreto significa experimento no listo, no completar ese
  campo con un identificador inventado.
- [ ] Métrica primaria predefinida: MAE H alineada al gauge en test; secundarias
  H raw, bloques por especie/distancia, bandas/gap y OOD cuando haya referencias.
  Promoción requiere razón geométrica pareada de MAE primaria <1 y ninguna
  degradación OOD pareada por encima del 5%; si dispersión/intervalos no permiten
  concluir, resultado inconcluso, no promoción. Mismo H0/gauge/pérdidas entre
  variantes, sin modificar física 4.4–4.5 durante la comparación.
- [ ] GPU: batch fijo y máximo batch separadamente; forward/backward/paso,
  sincronización, warmup, median/MAD y peak allocated/reserved tras reset.
  Registrar GPU/software/dtype y AMP solo si se autoriza y valida aparte.
  Precisión o VRAM no evaluadas se mantienen pendientes. No ejecutar comandos
  GPU ni entrenamientos al redactar este protocolo.
- [ ] Commit scripts/tests/protocolo/resultados reales; informar cualquier
  regresión de tiempo o memoria, no promover defaults.

