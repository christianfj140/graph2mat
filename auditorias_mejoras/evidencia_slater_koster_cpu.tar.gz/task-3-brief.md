### Task 3: MatrixMACE, configuración, periódicas y checkpoint

**Files:** `models/mace.py`, documentación del selector en
`tools/lightning/models/mace.py`, nuevo `test_slater_koster_model.py`.

**Interfaces:** Misma API actual: `edge_block_readout=E3nnSlaterKosterEdgeBlock`,
`edge_block_readout_kwargs={'rank': 2}` para fixtures pequeñas. MACE publica
`data_for_readout['edge_vectors']=vectors` ya calculado con shifts; Graph2Mat
parea ese campo mediante `_data_get_edge_args`. No segunda conversión de base.

1. **RED — integración mínima.**

- [ ] Reutilizar `training_inputs` y `data_module_for` de
  `tools/lightning/tests/test_coefficient_matrix_training.py`; definir
  `sk_inputs(**kwargs)` reenviando selector y rank. Test parametrizado sobre
  C=1/2, grouping=point_type/basis_shape/max y mode=single/sum/mean, con
  reutilización de nodos activada/desactivada. Verificar fallo por vectores
  no publicados antes de cambiar MACE.

```python
model, batch, _ = sk_inputs(components=components, grouping=grouping, mode=mode)
out = model(batch.clone())
expected = ((out['node_labels']-batch.point_labels).square().sum()
            + 2*(out['edge_labels']-batch.edge_labels).square().sum())
expected /= batch.point_labels.numel() + 2*batch.edge_labels.numel()
loss = model.training_step(batch.clone(), 0)['loss']
torch.testing.assert_close(loss, expected, rtol=1e-10, atol=1e-12)
loss.backward()
```

2. **GREEN — plomería y guard.**

- [ ] Publicar vectores sin recalcular vecinos/shift ni modificar datos de
  entrada. Guard de `hamiltonian_local_context` inspecciona operaciones reales;
  conservar guard low-rank existente. El nuevo residual contenido debe quedar
  cubierto sin añadir un catálogo de clases si el guard actual ya lo encuentra.
- [ ] Test directo de `MatrixMACE` con subclase personalizada de `E3nnGraph2Mat`
  que selecciona SK; contexto prohibido falla al construir, no tras fit.
  Con `mp_cutoff`, readout conserva todas las aristas de matriz, no solo las MP.
- [ ] Comparar forward con/sin layout y coefficient-only con pérdidas/gradientes
  de matrices. Invalidar mapa certificado y comprobar fallback actual, no
  forzar ruta rápida. Cubrir un tipo ausente y datos sin edge de ese tipo.

3. **Periódicas, convenciones y posición.**

- [ ] Reutilizar patrón del oráculo periódico de `test_low_rank_edge_model.py`:
  sisl con s/p/d/f y conversiones de base reales; no importar su test como
  sustituto. Incluir homo/hetero, self-image de shift no cero, intercambio de
  extremos, permutación y supercelda equivalente. Probar al menos convenciones
  cartesian/spherical/siesta_spherical y las rotaciones con inversión.
- [ ] Diferencia finita de posiciones con topología congelada, lejos de cortes
  y cambio de vecinos; incluir shift periódico para que no desaparezca el
  gradiente geométrico. Comparar con autograd en componentes concretas.

4. **Dos pasos, serialización y defaults.**

- [ ] Test `pl.Trainer(accelerator='cpu', devices=1, max_steps=2, max_epochs=2,
  logger=False, enable_checkpointing=False, enable_progress_bar=False,
  enable_model_summary=False, num_sanity_val_steps=0)` y fixture de datos.
  Confirmar `global_step==2`, gradientes finitos y cambio efectivo en `sk_net`
  y residual de operaciones utilizadas. No exigir gradiente en tipos ausentes.
- [ ] `trainer.save_checkpoint(tmp_path/'sk.ckpt')`, reload estricto con
  `LitMACEMatrixModel.load_from_checkpoint(..., map_location='cpu',
  weights_only=False)` de checkpoint propio. Predicciones iguales y mapas
  no entrenables, rank/clase/C preservados. Repetir legacy quitando kwargs
  opcionales del checkpoint como hace test low-rank existente.
- [ ] Parsear class path con el mecanismo CLI/jsonargparse ya usado en
  `test_models.py`; sin nueva ruta de selección. Ejemplo esperado:

```yaml
model:
  edge_block_readout: graph2mat.bindings.e3nn.E3nnSlaterKosterEdgeBlock
  edge_block_readout_kwargs:
    rank: 4
```

- [ ] Comparar lista exacta de claves/defaults legacy con estado de base
  `8c8dc3e` mediante evidencia/fixture local obtenida antes de cambiar producto,
  no mediante otro worktree ni git checkout. Verificar ausencia de `sk_net`,
  `sk_transform` y `residual` nuevos en arquitectura default; comparar salidas
  exactas cargando los mismos pesos. Conservar límites de checkpointing/compile/
  AMP y documentar combinaciones no certificadas, sin ejecutarlas en CUDA.
- [ ] Ejecutar tests SK de modelo + low-rank + coefficient_matrix_training +
  hamiltonian_context + modelos/CLI existentes. Commit solo de Task 3.

