### Task 5: gates finales CPU, revisión y cierre auditable

**Files:** informe CPU, resultados/gates, roadmaps y registros de este plan/spec;
producto/tests únicamente para corregir hallazgos dentro del alcance aprobado.

**Interfaces:** Matriz de aceptación con cada requisito de spec §§3–6,
evidencia/commit/comando/exit/conteos y estado probado/fallido/pendiente. JSON
con benchmark y protocolo no sustituye logs de pruebas.

1. **Gates posteriores al último cambio de producto.**

- [ ] Ejecutar y registrar:

```bash
"$G2M_PY" -m pytest src/graph2mat/bindings/e3nn/modules/tests/test_slater_koster_readout.py src/graph2mat/tools/lightning/tests/test_slater_koster_model.py tests/test_slater_koster_benchmark.py -q --tb=short
"$G2M_PY39" -m pytest src/graph2mat/bindings/e3nn/modules/tests/test_slater_koster_readout.py src/graph2mat/tools/lightning/tests/test_slater_koster_model.py tests/test_slater_koster_benchmark.py -q --tb=short
"$G2M_PY" -m pytest src/graph2mat tests -q --tb=short
"$G2M_RUFF" check src tests
"$G2M_RUFF" check --no-respect-gitignore --include '*.py' auditorias_mejoras/bench_slater_koster_cpu.py
"$G2M_MYPY" --config-file pyproject.toml
"$G2M_PY39" -m compileall -q src/graph2mat/bindings/e3nn/modules/slater_koster.py src/graph2mat/models/mace.py src/graph2mat/tools/lightning/models/mace.py auditorias_mejoras/bench_slater_koster_cpu.py
git diff --check
```

- [ ] No considerar 2477/2 histórico como prueba actual. No omitir tests nuevos
  por faltar feature ni relajar oráculos para obtener verde. Entornos ausentes
  se informan; no instalar ni declarar el gate satisfecho.

2. **Revisión independiente final única (método Native).**

- [ ] Tras commits propios, pedir un revisor nuevo para todo el rango desde
  `8c8dc3e`, spec/plan/fixtures y benchmark. Solo revisión, sin agentes de
  implementación por tarea. Revisar en particular los cinco Review Focus y
  que SK no sea una rama siempre nula ni una reducción silenciosa de alcance.
- [ ] Por cada hallazgo importante: test RED de causa, fix mínimo, GREEN;
  repetir gates afectados y full CPU después del último fix de producto.
  No dejar Critical/Important abiertos ni convertirlos en skips. No reenviar
  revisiones repetitivas para acumular coste sin una nueva pregunta concreta.

3. **Informe y actualización precisa.**

- [ ] Registrar versiones, base/final SHA, comandos, RED/GREEN, counts/warnings,
  tolerancias justificadas, resultados crudos, tiempos/params/RSS con scopes,
  revisión y limitaciones. Tabla de aceptación basada en evidencia nueva.
- [ ] Separar explícitamente implementado/verificado CPU, fallido y pendiente.
  La suite de corrección no demuestra precisión científica. Reportar coste
  adicional frente a 7.1 si lo hay, además de comparación frente a baseline.
- [ ] Actualizar 7.4 y Task 4: código CPU solo si pasa todo; GPU/VRAM/precisión,
  bandas/OOD permanecen abiertos. No cerrar todo Task 4 ni tocar otros puntos.
- [ ] Commit local de documentación propia; comprobar estado de trabajo y
  preservar los untracked previos. Sin push, merge, borrados ni nueva rama.
- [ ] Auditar cada requisito y artefacto antes de marcar goal complete. Si
  cualquier prueba obligatoria falla/falta, continuar o explicar bloqueo real.
  No cerrar por presupuesto, plan escrito ni artefactos de intención.

## Evidencia de planificación (no implementación)

- Base de producto `8c8dc3e`; diseño `8d49845`; sin cambios de producto al
  redactar este plan. El usuario aprobó diseño, no una implementación existente.
- Probe CPU efímero, sin archivos de producto, el 2026-10-09: 16 pares la/lb
  y 30 integrales axiales unitarias; proyección sobre Y_L(n0) con L/paridad
  naturales da error máximo `1.3322676295501878e-15`, exit 0, float64.
  No probó rotaciones/gradientes/integración; Tasks 1–3 siguen obligatorias.
- Primera invocación del probe falló al importar e3nn antes de graph2mat:
  `torch.load` rechazó `slice` en constantes de e3nn 0.4.4. El bootstrap existente
  de `graph2mat/__init__.py` ya allowlistea `slice`. Se corrigió el orden de
  imports del probe, sin parche de entorno, sin desactivar weights_only y sin
  cambiar producto. Los ejemplos nuevos deben respetar ese orden.
- APIs gradcheck/functional_call contrastadas con documentación primaria de
  [PyTorch 2.11](https://github.com/pytorch/pytorch/blob/v2.11.0/docs/source/notes/extending.rst)
  y [torch.func](https://github.com/pytorch/pytorch/blob/v2.11.0/docs/source/func.api.md)
  mediante Context7; pruebas reales en Torch 2.4.1 del piso siguen pendientes.
- Self-review: spec §§1–2 → Constraints/arquitectura; §3 → Tasks 1–2; §4 →
  Tasks 2–3; §5 → Tasks 1–3/5; §6 → Task 4; §7 → Task 5. Cinco Review Focus
  asignados; ningún test, benchmark ni beneficio de implementación declarado.

## Handoff

Plan listo para revisión del usuario. Método conservado: **Native**, con una
revisión independiente final. Aprobar este plan permite ejecutar Tasks 1–5;
la aprobación del diseño por sí sola no inició esos cambios.
