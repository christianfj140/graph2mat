### Task 2: operación SK+residual, contrato, cutoff y derivadas

**Files:** `slater_koster.py`, export en `modules/__init__.py`, cambios acotados
en `matrixblock.py`, tests `test_slater_koster_readout.py`.

**Interfaces:** Operación pública seleccionable por mecanismos existentes:

```python
class E3nnSlaterKosterEdgeBlock(torch.nn.Module):
    _data_get_edge_args = ("edge_feats", "edge_vectors")
    requires_zero_edge_shift = True

    def __init__(self, irreps_in, irreps_out, edge_feats_irreps,
                 i_basis, j_basis, single_irreps_out, change_of_basis,
                 symmetry="ij", n_matrix_components=1, rank=4):
        # buffers pequeños sk_transform_0, ...; metadatos _sk_groups.
        # submódulos públicos de estado: sk_net y residual.
        # sk_irreps: irreps naturales realmente cubiertas por rama angular.

    def forward(self, edge_feats=None, edge_vectors=None, **tuple_kwargs):
        # Tensor[n_edges, irreps_out.dim], componentes en orden RTP existente.

    def _sk_coefficients(self, integrals, vectors):
        # integrals: [n, C, sum_ab(min(la,lb)+1)]; vectors: [n,3].
        # Privado; permite oráculos con V literal, sin desactivar gates públicos.
```

1. **RED — rama SK real y op opcional ausente.**

- [ ] Test de export y construcción mediante `E3nnIrrepsMatrixBlock`; helper
  local de test `sk_block(i_basis, j_basis, components=1, **kwargs)` usa
  `irreps={'node_feats_irreps': o3.Irreps('2x0e+1x1o'),
  'edge_feats_irreps': o3.Irreps('2x0e')}` y `symmetry='ij'`.
- [ ] Fijar V en `_sk_coefficients`, reconstruir mediante el wrapper y probar
  fórmulas analíticas s-s, s-p, p-p, por C1/C2 y dirección genérica. p-p:

```python
n = vectors / torch.linalg.vector_norm(vectors, dim=-1, keepdim=True)
expected = (v_pi[:, None, None] * torch.eye(3, dtype=n.dtype)
            + (v_sigma-v_pi)[:, None, None] * n[:, :, None] * n[:, None, :])
torch.testing.assert_close(actual, expected, atol=2e-12, rtol=2e-12)
```

- [ ] Ejecutar archivo nuevo; observar fallos por operación/export/metadatos
  ausentes, no por imports de terceros. Guardar fallo observado.

2. **GREEN — operación e inyección mínima.**

- [ ] En `matrixblock.py`, guardar/entregar i_basis/j_basis, single_irreps_out,
  Q, symmetry y C únicamente a parámetros explícitos de constructor solicitados
  por firma. Sin mutar dict `irreps` recibido ni cambiar llamadas legacy.
- [ ] Construir `residual=E3nnLowRankEdgeBlock(...)` sin modificar 7.1. Reutilizar
  `_ordered_inputs`, `_scalar_slices`/`_extract_scalars` existentes para routing
  y conditioning 0e; no asumir escalares al principio de features.
- [ ] Registrar transformaciones pequeñas por par como buffers; no registrar
  Q otra vez. MLP `Linear(condition_dim,32) -> SiLU -> Linear(32,C*n_integrals)`.
  Radiales promediadas y escalares de ambos extremos en orden estable; fuente
  node y edge distinguida aunque kwargs se inviertan. Núcleo de forward:

```python
radial = (edge_feats[0] + edge_feats[1]) * 0.5
gate = torch.tanh(radial.square().sum(-1, keepdim=True))
integrals = (self.sk_net(condition) * gate).reshape(n, C, n_integrals)
return (self._sk_coefficients(integrals, edge_vectors[0])
        + self.residual(edge_feats=edge_feats, **tuple_kwargs))
```

- [ ] Validar fuentes/tuple/shape/C/rank/dtype/device, radiales 0e, finitud,
  vectores opuestos y longitud no cero. Rechazar C distinto de 1/2, complejo,
  paridad no natural/l>3 y symmetry distinta de `ij` al construir cuando sea
  identificable. No confundir C2 real con SOC. Preservar lote n=0 sin `max()`.
- [ ] Normalizar vectores con escalado por máximo absoluto antes de su norma
  cuando sea necesario evitar underflow/overflow; no convertir longitud pequeña
  válida en cero ni clamplear dirección. Esta estabilidad no amplía el dominio
  a vectores realmente cero.
- [ ] Warning de alcance: eliminar solo irreps faltantes cubiertas por
  `sk_irreps`. Test con inputs escalares y f-f confirma L=6e angular y mantiene
  aviso de canales no naturales que el residual escalar no puede producir.
- [ ] Guard específico de `requires_zero_edge_shift`: `set_output_scaleshift`
  rechaza `shift_scalars=True`; forward rechaza shift no cero/no finito si
  scaleshift habilitado, incluidos buffers cargados manualmente. Escalado
  por irrep y `shift_scalars=False` siguen soportados y probados.

3. **O(3), libertad de marco y residual.**

- [ ] Repetir transporte de Task 1 con C1/C2, capas repetidas, ejes exactos,
  direcciones próximas a polos y rotaciones impropias. Verificar
  `B(Rn)=Di(R) B(n) Dj(R).T` y coeficientes con sus irreps.
- [ ] Test de gauge del marco usando `R` y `R @ Ry(phi)` con al menos dos phi;
  comparar ambos transportes y el forward sin cartas. Ningún Euler en producto.
- [ ] Apagar residual poniendo sus parámetros a cero; demostrar SK no nula.
  Apagar `sk_net` y controlar pesos del residual; demostrar un bloque que no
  queda axial en el marco del enlace. Mantener ambos sumandos entrenables.

4. **Gradientes, negativos y corte.**

- [ ] Gradcheck float64 para vectores y features no triviales. Incluir parámetros
  mediante functional_call, sin reasignar `.data`; patrón:

```python
from torch.func import functional_call
names, values = zip(*operation.named_parameters())
params = tuple(p.detach().clone().requires_grad_() for p in values)
def f(*new_params):
    return functional_call(operation, dict(zip(names, new_params)), (), kwargs)
assert torch.autograd.gradcheck(f, params, eps=1e-6, atol=1e-5, rtol=1e-4)
```

- [ ] Cubrir 0o en radial, rank bool/0, formas incorrectas, NaN/Inf, vectores
  iguales en ambas direcciones, cero, n=0, palabras clave invertidas, features
  repetidas/no contiguas y longitudes pequeñas representables (p. ej. 1e-20
  float32). Comprobar mensaje de error y no mutación de entradas.
- [ ] Con nodos fijos no nulos y el envelope radial existente, comprobar valor
  exactamente cero en/fuera del corte, límite interior y derivada radial cero.
  Incluir escalado de salida ajustado; shifts no nulos deben fallar.
- [ ] Ejecutar tests nuevos + `test_low_rank_edge_readout.py`,
  `test_coefficient_only_block.py`, `test_edge_pairing_and_safety.py`.
  Guardar evidencia y commit propio de Task 2.

