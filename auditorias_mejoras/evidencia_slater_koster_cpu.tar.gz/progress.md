# SDD ledger — plan: docs/superpowers/plans/2026-10-09-slater-koster-readout-7-4.md

User approved design and plan (2026-10-09); Native execution. Product base 8c8dc3e; execution base 3981be9.
Task 1: complete — calibration and independent angular oracles.
Task 2: complete — optional SK+residual, contracts and derivatives.
Task 3: complete — MACE/config/periodic/checkpoints.
Task 4: complete — paired CPU benchmark and GPU/precision protocol.
Task 5: complete — final CPU gates, independent review and evidence report.
Task 5 aggregate gate: full-cpu.log, 2597 passed / 2 existing skipped,36532warnings,850.43s,exit0; session31312 consumed. Product/tests HEAD8a5cc7c unchanged throughout all final gates. No open CPU failures or deferred minors.

Pre-flight: Tasks 1→2 use (_sk_groups, transform) and one-component Q; C replication only in Task 2, consistent.
Pre-flight: Tasks 2→3 consume edge_vectors paired directions, MatrixMACE must publish computed vectors, consistent.
Pre-flight: Tasks 3→4 consume existing class selectors; legacy benchmark helpers return only summaries, new runner must retain raw samples without altering 7.1.
Pre-flight: Tasks 1–4→5 require focused tests and raw evidence, no CPU result proves GPU/precision, consistent.
Ruling: user explicitly requires same checkout and no installs — using-git-worktrees setup honors that override; keep g2m-v2 in place. Cost if wrong: no isolated checkout rollback; own commits preserve recovery.

Commands use CUDA_VISIBLE_DEVICES='', absolute PYTHONPATH and OMP/OPENBLAS/MKL threads=2.
Artifacts live in this workspace; no foreign data/processes touched.

Baseline: 42 low-rank operation/model tests passed, 2715 warnings, 33.80s; legacy-default.pt saved (165 state keys).
Task 2 broad gate: 209 passed, 1 existing skipped, 7526 warnings, 54.22s. Two fixture errors corrected (PointBasis parity validation precedes wrapper; TorchScript warning precedes scientific warning).
Task 3 RED: missing edge_vectors field, task3-red.log; fixed by publishing existing directed vectors only.
Task 3 max-group RED: max table includes zero-multiplicity 0x4e placeholder; _shells rejected an absent orbital. Ignore mul=0 without accepting any occupied l>3.
Task 3: Ruling: CLI parser examples actually live in test_cli.py, not test_models.py — reuse existing LightningArgumentParser there — no new selection API; cost if wrong: CLI type handling could differ from a full command (covered again by existing CLI gate).
Task 3: Ruling: keep portable default-key digest regression, run captured-weight/prediction equivalence as local execution gate — avoid introducing a scratch-file skip into the test suite — cost if wrong: CI only checks key/default invariants, not the execution-only legacy output capture.
Task 3 gate: 291 passed, 21059 warnings, 313.64s; task3-gate.log. Initial gate command referenced nonexistent lightning/tests/test_hamiltonian_context.py; actual tests live in bindings/e3nn/modules/tests (corrected command before gate).
Legacy execution gate: 165 keys unchanged, strict load, exact float64 node/edge predictions unchanged vs preimplementation capture; legacy-equivalence.log exit0.
Operation floor gate: Python3.9/Torch2.4.1, 70 passed, 347 warnings, 6.82s; operation-python39.log.
Controlled ablation: nonzero SK and residual, residual component orthogonal to axial SK family, weight-zeroing branch identity; task3-ablation.log 1 passed.
Task 4 RED: test_three_variant_cpu_benchmark_contract failed because script was absent; task4-red.log.
Task 4 smoke GREEN: 1 passed in 44.14s; task4-smoke.log. First implementation smoke exposed missing node_feats_irreps=None in isolated fixture; followed existing wrapper contract, no product change.
Task 4: Ruling: initial spawned RSS workers ran after parent allocated all three timing models; Linux exec retains the parent's high-water RSS (local probe: parent142224KiB, fresh child142224KiB after128MiB allocation). Start RSS workers BEFORE timing models — avoids ceiling contamination without changing the approved ru_maxrss/spawn method — cost if wrong: inherited import-only floor could still hide small differences; report construction/import scope, not readout-only memory. Initial benchmark RSS is superseded, raw JSON retained as benchmark72-rss-superseded.json.
RSS ordering regression: rss-order-red.log verifies old order fails (['model'] instead of ['memory','model']); fix moves host_memory before model construction, checks shared hashes afterwards.
Task 4 final measurement: f0acdad, 72 points/432 directed edges, rank4, rounds12/warmup3. Full-step ms baseline392.043, low_rank184.953, SK190.720; RSS MiB1943.51/1214.85/1216.09, construction/import/four-Adam-step scope. Actual JSON and preliminary report committed 8a5cc7c. Unit source routing/0e regression71 passed in5.65s. Benchmark Python3.9 smoke2 passed in51.59s (65warnings).
Task 5 final gates launched on 8a5cc7c: focused Python3.12, focused Python3.9, complete CPU suite; separate handles, no benchmark performance measurement concurrent. Final independent read-only review can run alongside these gates; no closure before both are satisfied.
Task 5 focused gates: Python3.12/Torch2.11cpu 120 passed,6462warnings,142.22s; Python3.9/Torch2.4.1 120 passed,3023warnings,171.40s. Logs focused-python312.log/focused-python39.log. All new tests ran, no skips.
Task 5 static gates exit0: Ruff src/tests and explicit benchmark script; mypy23corefiles; compileallPython3.9; gitdiffcheck. Logs ruff.log/ruff-benchmark.log/mypy.log/compile39.log/diff-check.log. Pipcheck exit0.
Final independent review: fresh gpt-6-astra /sk_7_4_final_review, range8c8dc3e..8a5cc7c, final-review.md. Critical0/Important0/Minor0 after parent regrading; no fix pass required. Additional C2 repeated-shell improper-rotation error3.774758283725532e-15; dtype reload, directed losses3groups and real scale fit passed. No deferred minors.
Final: Ruling: scientific accuracy/bands/gap/OOD/promotion set aside by reviewer — keep explicitly unevaluated, synthetic correctness is not material accuracy — cost if wrong: an optional prior might worsen real predictions; defaults remain unchanged.
Final: Ruling: GPU/VRAM/AMP/compile/checkpointing set aside by reviewer — no new certification, preserve existing restrictions and approved CPU-only scope — cost if wrong: untested execution modes may fail or regress.
Final: Ruling: performance outside measured fixture/host set aside by reviewer — only report actual synthetic CPU timings and construction-inclusive RSS — cost if wrong: timings/memory may differ substantially on other datasets/hardware.
Final: Ruling: arbitrary Q/map corruption or inconsistent generated-metadata overrides set aside by reviewer — support normal generated construction, dtype conversion and strict own checkpoints, not manual internal-state surgery — cost if wrong: incoherent custom/tampered states can invalidate scientific maps and are not certified.
Final: Ruling: aggregate gate success set aside by reviewer — parent's actual final gates govern closure, not review verdict — cost if wrong: premature completion could hide regressions; wait for exit0 and preserve logs.
Task 5: Ruling: installed Ruff rejects --include; use equivalent --config 'include=["*.py"]' plus --no-respect-gitignore to check ignored audit script — same rule selection, no install — cost if wrong: file discovery scope could differ (explicit script argument checked).
Task 1 RED: 37 failures, missing calibration, task1-red.log. Initial GREEN attempt exposed nonaxial permutation acceptance (36/37); root cause axial-only checks. Added orbital/irrep intertwiner certification using fixed generic rotation; no tolerance relaxation.
Task 1: complete (commits 3981be9..92e1ad3, tests: /tmp/g2m-python312-full.LHyni1/venv/bin/python -m pytest src/graph2mat/bindings/e3nn/modules/tests/test_slater_koster_readout.py -q --tb=short → 37 passed, 379 warnings in 2.30s)
Task 2: complete (commits 92e1ad3..80f3cf5, tests: /tmp/g2m-python312-full.LHyni1/venv/bin/python -m pytest src/graph2mat/bindings/e3nn/modules/tests/test_slater_koster_readout.py -q --tb=short → 69 passed, 742 warnings in 4.95s)
Task 3: complete (commits 80f3cf5..9c50ee5, tests: /tmp/g2m-python312-full.LHyni1/venv/bin/python -m pytest src/graph2mat/bindings/e3nn/modules/tests/test_slater_koster_readout.py src/graph2mat/tools/lightning/tests/test_slater_koster_model.py -q --tb=short → 117 passed, 6440 warnings in 89.99s (0:01:29))
Task 4: complete (commits 9c50ee5..f0acdad, tests: /tmp/g2m-python39.D7TJAp/full-venv/bin/python -m pytest tests/test_slater_koster_benchmark.py -q --tb=short → 2 passed, 65 warnings in 51.59s)
Cleanup: Ruling: preserve this plan's ignored scratch and commit a full evidence archive instead of deleting it — approved plan explicitly forbids deletions, overriding skill scratch cleanup — cost if wrong: ignored scratch can be lost by git clean; versioned archive preserves the proof. Keep branch g2m-v2 in the explicitly chosen checkout; no push/merge.
Skip reason check: skip-reasons.log exit0, 2 existing skipped,51warnings,0.07s; confirms absent example HSX and GPU-only torch.compile/inductor test. No new skips introduced.
Task 5: complete (commits 8a5cc7c..d782b4d, tests: /tmp/g2m-python312-full.LHyni1/venv/bin/python -m pytest src/graph2mat/bindings/e3nn/modules/tests/test_slater_koster_readout.py src/graph2mat/tools/lightning/tests/test_slater_koster_model.py tests/test_slater_koster_benchmark.py -q --tb=short → 120 passed, 6462 warnings in 134.99s (0:02:14))
Final closure audit: Tasks1–5 accepted; full CPU2597/2 exit0, focused120 Python3.12 and3.9 exit0, static gates exit0, legacy165 strict exact-output exit0, benchmark hashes/raw summaries consistent, review0/0/0 and no deferred minors. Closing rerun120 passed/6462warnings/134.99s exit0. Product/tests unchanged from8a5cc7c, documentation commitd782b4d. Benchmark finalJSON SHA256c9a4b1620065c4a95036cf745b4c304bd2091c02c0a0919f823c16b604a699fb. Evidence archive contains this complete ledger and all logs. No GPU/scientific precision executed; 7.4 experimental/Task4 global remain open. Existing foreign untracked preserved; same branch/checkout, no installs/push/merge/deletions.
