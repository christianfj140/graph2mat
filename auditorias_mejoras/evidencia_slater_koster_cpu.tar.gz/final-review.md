# Independent final review — sk_7_4_final_review

Model gpt-6-astra, fresh context, read-only; base8c8dc3e..head8a5cc7c,
approved spec/plan and ledger. No subagents or changes. Final findings:
**Critical0 / Important0 / Minor0**. Ready from code/scientific-integration
review; final aggregate gates and roadmap closure remain parent's duty.

Confirmed: Q support preserves repeated radial shells; angular calibration
orthogonality/reconstruction/intertwiner/rank; tiny positive vector normalization
without clamp; finite/directed/source validation; custom-context guard and loaded
shift rejection; persistent Q/T buffers; source-name ordering and only0e;
certified coefficient fallback; effective branches and periodic/gradient tests.
All saved source hashes and18timing summaries match raw data. RSS workers run
before parent timing models. No performance extrapolation made.

Additional reviewer CPU diagnostics (exit0, Python3.12/Torch2.11cpu,
CUDA empty, absolute PYTHONPATH, two threads, PYTHONDONTWRITEBYTECODE=1):

- Repeated2s2p1d1f vs1s2p1f, C2, improper rotation: maximum orbital absolute
  error3.774758283725532e-15; atol=rtol2e-12.
- Strict float64→float32 reload of Q/SKmaps: atol=rtol2e-5 passed.
- Directed nonsymmetric C2 coefficient/matrix losses for all3groupings:
  rtol1e-10/atol1e-12 passed.
- Actual graph-level output-scale fitting+C2 forward: finite node/edge outputs.
- Provenance: every source SHA matches; measured product/script unchanged
  since f0acdad; all raw lengths/median/MAD/min/max and shared RSS hashes valid.

Reproduction supplied by reviewer:

```python
import graph2mat
import torch
from copy import deepcopy
from e3nn import o3
from graph2mat import PointBasis
from graph2mat.bindings.e3nn import E3nnSlaterKosterEdgeBlock
from graph2mat.bindings.e3nn.modules.matrixblock import E3nnIrrepsMatrixBlock
from graph2mat.bindings.e3nn.modules.tests.test_slater_koster_readout import shell_ranges
from graph2mat.tools.lightning.tests.test_slater_koster_model import sk_inputs
torch.set_default_dtype(torch.float64)
torch.manual_seed(54)
a = PointBasis('A', R=2, basis='2x0e+2x1o+1x2e+1x3o')
b = PointBasis('B', R=2, basis='1x0e+2x1o+1x3o')
block = E3nnIrrepsMatrixBlock(a, b, 'ij', E3nnSlaterKosterEdgeBlock,
    irreps={'node_feats_irreps': o3.Irreps('1x0e'), 'edge_feats_irreps': o3.Irreps('2x0e')},
    n_matrix_components=2, rank=1)
op = block.operation
R = -o3.angles_to_matrix(*[torch.tensor(x) for x in (.34, -.27, .76)])
v = R @ torch.tensor([0., 1., 0.])
V = torch.randn(1, 2, op.n_integrals)
expected = torch.zeros(1, a.basis_size, b.basis_size, 2)
offset = 0
for ra, ea, ia in shell_ranges(a):
    for rb, eb, ib in shell_ranges(b):
        axis = torch.zeros(ia.dim, ib.dim, 2)
        for q in range(min(ia.l, ib.l)+1):
            axis[ia.l-q, ib.l-q] = V[0, :, offset+q]
            axis[ia.l+q, ib.l+q] = V[0, :, offset+q]
        expected[:, ra:ea, rb:eb] = torch.einsum('ai,ijc,bj->abc', ia.D_from_matrix(R), axis, ib.D_from_matrix(R))
        offset += min(ia.l, ib.l)+1
actual = block.coefficients_to_block(op._sk_coefficients(V, v[None]))
torch.testing.assert_close(actual, expected, atol=2e-12, rtol=2e-12)
converted = deepcopy(block).float()
converted.load_state_dict(block.state_dict(), strict=True)
actual = converted.coefficients_to_block(converted.operation._sk_coefficients(V.float(), v.float()[None]))
torch.testing.assert_close(actual.double(), expected, atol=2e-5, rtol=2e-5)
for grouping in ('point_type', 'basis_shape', 'max'):
    model, batch, _ = sk_inputs(components=2, grouping=grouping, symmetric=False)
    out = model(batch.clone())
    expected_loss = ((out['node_labels']-batch.point_labels).square().sum()
        + 2*(out['edge_labels']-batch.edge_labels).square().sum()) / (
        batch.point_labels.numel()+2*batch.edge_labels.numel())
    torch.testing.assert_close(model.training_step(batch.clone(), 0)['loss'], expected_loss, rtol=1e-10, atol=1e-12)
model, batch, _ = sk_inputs(components=2, coefficient_training=False, output_scaleshift=True)
readout = model.model.matrix_readouts
readout.fit_output_scaleshift([batch], model.basis_table)
assert readout.output_scaleshift_fitted
out = model(batch.clone())
assert all(torch.isfinite(out[k]).all() for k in ('node_labels', 'edge_labels'))
```

Declined to judge, exhaustively:
1. Scientific accuracy/bands/gap/OOD/promotion: synthetic fixtures lack evidence.
2. GPU/VRAM/AMP/compile/checkpointing compatibility: outside CPU certification.
3. Performance beyond recorded fixture/host: no extrapolation.
4. Arbitrary manual corruption of internal Q/maps or inconsistent overrides of
   generated metadata: normal construction, dtype conversion and strict own
   checkpoint loading reviewed, internal-state mutation not supported workflow.
5. Aggregate gates: parent running them, review does not substitute for exit0.

Parent regraded by reasonable-user effect: no product findings to fix;
bounded claims stand, every declined behavior explicitly ledgered as Ruling.
No deferred minors and no second review needed.
