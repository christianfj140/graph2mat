### Task 1: mapas SK por capa y oráculos independientes

**Files:** Crear `slater_koster.py` y `test_slater_koster_readout.py` en los
directorios indicados. No integrar todavía en MACE ni exportar operación incompleta.

**Interfaces:**

```python
def _sk_couplings(i_basis, j_basis, single_irreps_out, change_of_basis):
    # list[(segments, transform)] en orden de pares de capas expandidas.
    # segments: tuple[(coefficient_start, coefficient_stop, L), ...]
    # transform: Tensor[len(segments), min(la, lb)+1], sin gradiente.
    # Q de UN componente; los componentes se duplican en Task 2.
```

1. **RED — prueba axial y rotada, sin reutilizar calibración como oráculo.**

- [ ] Crear test parametrizado sobre los 16 pares la/lb=0..3 y cada q admitido.
  Construir Q con `ReducedTensorProducts('ij', ...)`, bases con una capa y el
  bloque axial literal; importar `graph2mat` antes de e3nn para usar el bootstrap
  de serialización ya existente. Núcleo del oráculo:

```python
axis = torch.zeros(2 * la + 1, 2 * lb + 1, dtype=torch.float64)
axis[la - q, lb - q] = 1
axis[la + q, lb + q] = 1
R = o3.angles_to_matrix(*(torch.tensor(x, dtype=torch.float64)
                         for x in (0.31, 0.73, -0.29)))
n = R @ torch.tensor([0., 1., 0.], dtype=torch.float64)
expected = (o3.Irrep(la, (-1)**la).D_from_matrix(R) @ axis
            @ o3.Irrep(lb, (-1)**lb).D_from_matrix(R).T)
groups = _sk_couplings(i_basis, j_basis, rtp.irreps_out, rtp.change_of_basis)
segments, transform = groups[0]
coeff = torch.zeros(rtp.irreps_out.dim, dtype=torch.float64)
for k, (start, stop, L) in enumerate(segments):
    coeff[start:stop] = transform[k, q] * o3.spherical_harmonics(
        L, n, normalize=True, normalization="component")
actual = torch.einsum("k,kij->ij", coeff, rtp.change_of_basis)
torch.testing.assert_close(actual, expected, atol=2e-12, rtol=2e-12)
assert torch.linalg.matrix_rank(transform) == min(la, lb) + 1
```

- [ ] Ejecutar `"$G2M_PY" -m pytest src/graph2mat/bindings/e3nn/modules/tests/test_slater_koster_readout.py -q --tb=short`; verificar fallo por helper ausente.

2. **GREEN — calibración mínima, sin construir marcos en forward.**

- [ ] Expandir cada multiplicidad en capas radiales separadas. Localizar cada
  instancia de irrep con su soporte en Q y sus offsets, no solo con l/dimensión.
  Para cada capa y q, proyectar el axial literal con Q y comprobar el soporte
  esperado. Fórmula de amplitud por segmento:

```python
y0 = o3.spherical_harmonics(L, n0, normalize=True, normalization="component")
projected = torch.einsum("kij,ij->k", Q_segment, axial)
amplitude = (projected * y0).sum() / y0.square().sum()
torch.testing.assert_close(projected, amplitude * y0, **calibration_tolerances)
```

- [ ] Comprobar L/paridad permitidos, rango, reconstrucción completa y
  dimensiones/Q finito; rechazar Q incompatible y bases no naturales/l>3.
  No persistir copia completa adicional de Q en operación ni matriz KxK.
  Calibrar en dtype de Q; conservar precisión generando Q float64 cuando la
  prueba lo exige, no convirtiendo Q float32 y pretendiendo recuperarla.

3. **Regresiones de identidad.**

- [ ] Añadir caso `2x0e+2x1o+1x2e+1x3o` frente a `1x0e+2x1o+1x3o`;
  activar una única integral de un único par y verificar bloque cero fuera de
  ese par. Repetir todos los pares, no solo la primera capa. Alterar Q con una
  permutación no certificada y comprobar error de calibración, no éxito aparente.
- [ ] Repetir tests con default float32 y float64 restaurando dtype al terminar.
  Presupuestos iniciales: float64 2e-12, float32 2e-5 para oráculo angular;
  cualquier ajuste exige identificar su fuente numérica, no tapar un fallo.
- [ ] Guardar RED/GREEN en evidencia y commit local solo de estos dos archivos.

